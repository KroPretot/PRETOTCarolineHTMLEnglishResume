# PRETOT Caroline HTML english resume
It contains my work experiences, my education, my skills anf my interests and recreational activities. You can also find my contact details on it.
